import React from 'react';
import { useTranslation } from 'react-i18next';
import { Link } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap-icons/font/bootstrap-icons.css';
import './css/Footer.css'

const Footer = () => {
  const { t } = useTranslation();

    return (
        <footer className="bg-dark text-white py-4 px-5 ">
        <div className="">
          <div className="row">
            {/* Первая колонка */}
            <div className="col-lg-3 col-md-6 mb-4">
              <h3 className="h5"><span className='text-primary-emphasis'>{t('footer.about.left')}</span>{t('footer.about.right')}</h3>
              <p>{t('footer.about.desc')}</p>
            </div>
            {/* Вторая колонка */}
            <div className="col-lg-3 col-md-6 mb-4 ps-lg-5">
              <h3 className="h5"><span className='text-primary-emphasis'>{t('footer.quickLinks.left')}</span>{t('footer.quickLinks.right')}</h3>
              <ul className="list-unstyled">
                <li>
                  <Link to="/" className="text-white text-decoration-none">
                    {t('nav.home')}
                  </Link>
                </li>
                <li>
                  <Link to="/about" className="text-white text-decoration-none">
                    {t('nav.about')}
                  </Link>
                </li>
                <li>
                  <Link to="/services" className="text-white text-decoration-none">
                    {t('nav.services')}
                  </Link>
                </li>
                <li>
                  <Link to="/portfolio" className="text-white text-decoration-none">
                    {t('nav.portfolio')}
                  </Link>
                </li>
                <li>
                  <Link to="/contact" className="text-white text-decoration-none">
                    {t('nav.contact')}
                  </Link>
                </li>
              </ul>
            </div>
            {/* Третья колонка */}
            <div className="col-lg-3 col-md-6 mb-4">
              <h3 className="h5"><span className='text-primary-emphasis'>{t('footer.contact-left')}</span>{t('footer.contact-right')}</h3>
              <p>{t('footer.address')}</p>
              
              <p>
                +380 987 654 321  
                <br/> +420 728 056 984
              </p>
              
              <p>
                <span className='text-primary-emphasis'>add.software.developer@gmail.com</span>
                
              </p>
            </div>
            {/* Четвертая колонка */}
            <div className="col-lg-3 col-md-6 mb-4">
              <h3 className="h5"><span className='text-primary-emphasis'>{t('footer.followUs-left')}</span>{t('footer.followUs-right')}</h3>
              <div>
                <a href="#"
                  className="text-white me-1"
                  aria-label="Facebook">
                  <i className="bi bi-facebook"></i>
                </a>
                <a href="#"
                  className="text-white me-1"
                  aria-label="Twitter">
                  <i className="bi bi-twitter"></i>
                </a>
                <a href="#"
                  className="text-white me-1"
                  aria-label="LinkedIn">
                  <i className="bi bi-linkedin"></i>
                </a>
                <a href="#"
                  className="text-white"
                  aria-label="Instagram">
                  <i className="bi bi-instagram"></i>
                </a>
              </div>
            </div>
          </div>
          <div className="text-center pt-4 border-top">
            <p>
              &copy; {new Date().getFullYear()} AddSoftware.{' '}
              {t('footer.allRightsReserved')}
            </p>
          </div>
        </div>
      </footer>
  );
};

export default Footer;