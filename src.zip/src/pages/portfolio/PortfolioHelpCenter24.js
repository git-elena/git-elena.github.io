import React from 'react'
import imgBanner from '../../../images/portfolio/'

const PortfolioHelpCenter24 = () => {
  return (
    <div className='portfolio-page  page-content'>
      <div className='portfolio-banner'>
        <img className='img-fluid' src='' />
      </div>
    </div>
  )
}

export default PortfolioHelpCenter24
